package com.gitbitex.exception;

public enum ErrorCode {
    INSUFFICIENT_FUNDS,
}
