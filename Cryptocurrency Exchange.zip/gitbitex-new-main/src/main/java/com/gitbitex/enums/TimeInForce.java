package com.gitbitex.enums;

public enum TimeInForce {
    GTC,
    GTT,
    IOC,
    FOK,
}
