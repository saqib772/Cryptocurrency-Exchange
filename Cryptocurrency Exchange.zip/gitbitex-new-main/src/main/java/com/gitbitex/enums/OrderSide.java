package com.gitbitex.enums;

public enum OrderSide {
    /**
     * buy
     */
    BUY,
    /**
     * sell
     */
    SELL
}
