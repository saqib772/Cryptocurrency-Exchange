package com.gitbitex.enums;

public enum OrderStatus {
    REJECTED,
    RECEIVED,
    OPEN,
    CANCELLED,
    FILLED,
}
