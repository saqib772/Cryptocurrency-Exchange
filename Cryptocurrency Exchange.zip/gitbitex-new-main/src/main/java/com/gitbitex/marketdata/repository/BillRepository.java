package com.gitbitex.marketdata.repository;

import org.springframework.stereotype.Component;

@Component
public class BillRepository {

}
