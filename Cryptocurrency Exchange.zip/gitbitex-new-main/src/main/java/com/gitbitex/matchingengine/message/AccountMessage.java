package com.gitbitex.matchingengine.message;

import com.gitbitex.matchingengine.Account;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountMessage extends Account {
}
