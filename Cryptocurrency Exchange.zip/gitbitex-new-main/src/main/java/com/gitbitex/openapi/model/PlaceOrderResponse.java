package com.gitbitex.openapi.model;

public class PlaceOrderResponse {
}
