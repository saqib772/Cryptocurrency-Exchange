package com.gitbitex.openapi.model;

public class ChangePasswordRequest {
    private String email;
    private String password;
    private String code;
}
